export const PAYMENT_MODE = {
    ONLINE: 1,
    CASH: 2,
    ONLINE_AND_CASH: 3,
};
export const PAYMENT_MODE_TEXT = {
    [PAYMENT_MODE.ONLINE]: "Pay at hotel",
    [PAYMENT_MODE.CASH]: "Partial payment",
    [PAYMENT_MODE.ONLINE_AND_CASH]: "Full payment",
};
export const PAYMENT_STATUS = {
    PENDING: 1,
    PARTIAL_PAYMENT: 2,
    FULL_PAYMENT: 3,
};
export const PAYMENT_STATUS_TEXT = {
    [PAYMENT_STATUS.PENDING]: "Confirmed",
    [PAYMENT_STATUS.PARTIAL_PAYMENT]: "Confirmed",
    [PAYMENT_STATUS.FULL_PAYMENT]: "Confirmed",
};