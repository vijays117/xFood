import React, { useState, useEffect } from 'react';
import { Link, useParams } from 'react-router-dom';
import { useDispatch, useSelector } from 'react-redux';
import ReactPaginate from 'react-paginate';
import ImagesData from '../../assets/ImagesData.js';
import { fetchMenus } from '../../store/slices/menuSlice';
import { fetchCategories } from '../../store/slices/categorySlice';
import { addToCart } from '../../store/slices/cartSlice';
import FormatPrice from '../../utils/format-price';
import DummyImage from '../../utils/dummy-image';
import { showToast } from '../../utils/toaster';
import apiService from '../../API/api/Api.js';

const Menus = () => {

	const { IconList, IconGrid } = ImagesData;
	const { id } = useParams();
	const dispatch = useDispatch();
	const { access_token } = useSelector((state) => state.authSlice);
	const { menus } = useSelector((state) => state.menuSlice);
	const { categories } = useSelector((state) => state.categorySlice);
	const { carts } = useSelector((state) => state.cartSlice);
	const [filterData, setFilterData] = useState(menus);
	const [selectedFilter, setSelectedFilter] = useState('');
	const [view, setView] = useState(false)

	useEffect(() => {
		dispatch(fetchMenus(id))
		dispatch(fetchCategories())
	}, [])

	const handleCarts = (item) => {
		if (access_token) {
			dispatch(addToCart(item))
			showToast('Item added Successfully', 'success')
		}
		else {
			showToast('Please Login', 'error')
		}
	}

	const handleFilterbyPrice = (e) => {
		let filteValue = e.target.value
		setSelectedFilter(filteValue)
		const [min, max] = filteValue.split('-').map(Number);
		const filtered = menus.filter(product => product.price >= min && product.price <= max);
		setFilterData(filtered);
	}

	const handleCategoryFilter = (cate) => {
		console.log(cate)
		const filtered = menus.filter((item) => item.catID == cate)
		setFilterData(filtered)
	}

	const handleSearch = async(e)=>{
		let {value} = e.target;
		const response = await apiService.get(`/Searchproduct?query=${value}`)
		if(response.status == '200'){
			setFilterData(response.outlet_menu_data)
		}
	}

	const gridView = () => {
		setView(true)
	}

	return (
		<div className='section listing-section'>
			<div className='container'>
				<div className='row'>
					<div className='col-lg-3'>
						<div className='sidebar'>
							<div className='box'>
								<h3>Filter by Name</h3>
								<input type='text' className='form-control' onChange={handleSearch} placeholder='Search...' />
							</div>
							<div className='box'>
								<h3>Filter by Price</h3>
								<ul>
									<li>
										<label className='h-center'><input type='radio' name="price" value='0-50' checked={selectedFilter == '0-50'} onChange={handleFilterbyPrice} />0 - 50</label>
									</li>
									<li>
										<label className='h-center'><input type='radio' name="price" value='50-100' checked={selectedFilter == '50-100'} onChange={handleFilterbyPrice} />50 - 100</label>
									</li>
								</ul>
							</div>
							<div className='box'>
								<h3>Categories</h3>
								<ul>
									{
										categories?.map((category) => {
											return (
												<li key={category.cat_id}><Link onClick={() => handleCategoryFilter(category.cat_id)}>{category.cat_name}</Link>
												</li>
											)
										})
									}
								</ul>
							</div>
						</div>
					</div>
					<div className='col-lg-9'>
						<div className='sorting-controls'>
							<div className='row align-items-center'>
								<div className='col-lg-6'>
									{/* {currentPage + 1}–{Math.ceil(menus?.length / itemsPerPage)} of */}
									<p>Showing {menus?.length} results</p>
								</div>
								<div className='col-lg-6 d-flex justify-content-end align-items-center'>
									<ul className='view-control d-flex'>
										<li><span className='icon-img-inline'><img src={IconGrid} className='d-flex' title='' /></span></li>
										<li><span className='icon-img-inline' onClick={gridView}><img src={IconList} className='d-flex' title='' /></span></li>
									</ul>
									<div className='select-box'>
										<select className='form-control'>
											<option>Default Sorting</option>
										</select>
									</div>
								</div>
							</div>
						</div>
						<div className='listing-panel text-center'>
							<div className='row'>
								{
									filterData?.map((menu, i) => {
										return (
											<div className={`col-lg-4 ${view ? 'col-lg-12' : 'col-lg-4'}`} key={i}>
												<div className='column'>
													<div className='img all-center'>
														<DummyImage imgs={`https://saddaaddarestaurant.com/adminlogin/images/${menu?.item_image}`} />
													</div>
													<div className='text'>
														<h3>{menu?.item_name?.slice(0, 12)}</h3>
														<p><FormatPrice price={menu?.price} /></p>
														<button
															type='button'
															className='btn btn-secondary btn-sm'
															onClick={() => handleCarts(menu)}>Add to Cart</button>
													</div>
												</div>
											</div>
										)
									})
								}
							</div>
							{/* <ReactPaginate
								previousLabel="Previous"
								nextLabel="Next"
								pageCount={Math.ceil(menus?.length / itemsPerPage)}
								onPageChange={handlePageChange}
								containerClassName="pagination"
								activeClassName="active"
							/> */}
						</div>
					</div>
				</div>
			</div>
		</div>
	)
}

export default Menus;