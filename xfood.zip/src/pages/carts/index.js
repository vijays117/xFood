import React, { useState, useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { Link } from 'react-router-dom';
import ImagesData from '../../assets/ImagesData.js';
import Components from '../../component/'
import Counter from '../../utils/counter';
import FormatPrice from '../../utils/format-price';
import { couponDiscount } from '../../store/slices/cartSlice';
import { showToast } from '../../utils/toaster/index';
import { removeItemFromCart, increment, decrement, getSubTotal } from '../../store/slices/cartSlice';

const Carts = () => {

	const { IconClose, NoCartImage } = ImagesData;
	const { CartTotal } = Components;
	const dispatch = useDispatch();

	const { access_token } = useSelector((state) => state.authSlice)
	const { carts, coupons } = useSelector((state) => state.cartSlice)
	const [coupon, setCoupon] = useState('');

	const couponCodes = [
		{ code: 'AZDFG11', amount: 20 }
	]
	const handleCoupon = () => {
		const foundCode = couponCodes.find((item) => item.code === coupon);
		if (coupon.length == 7 && foundCode) {
			dispatch(couponDiscount(foundCode))
			showToast('Coupon Applied', 'success');
		}
		else {
			showToast('Please Enter Valid Coupon Code', 'error');
		}
	}

	useEffect(() => {
		dispatch(getSubTotal());
	})

	const removeCart = (id) => {
		dispatch(removeItemFromCart(id))
	}

	const decrementQuantity = (cart) => {
		dispatch(decrement(cart))
	}

	const incrementQuantity = (cart) => {
		dispatch(increment(cart))
	}
	
	return (
		<div className='section-sm cart-section'>
			<div className='container'>
				{
					access_token ? (
						<>
							<div className='heading'>
								<h3>Carts - {carts?.length}</h3>
							</div>
							{
								carts.length > 0 ? (
									<div className='row'>
										<div className='col-lg-9'>
											<div className='table-wrapper'>
												<table className='table'>
													<thead>
														<tr>
															<th>Product</th>
															<th>Price</th>
															<th>Quantity</th>
															<th>Total Price</th>
															<th>Action</th>
														</tr>
													</thead>
													<tbody>
														{
															carts?.map((cart, i) => {
																return (
																	<tr key={i}>
																		<td>{cart.product_name}</td>
																		<td><FormatPrice price={cart.price} /></td>
																		<td>
																			{/* <div className='counter'>
																				<button type='button' onClick={() => decrementQuantity(cart)} className='btn-icon default'>-</button>
																				<input type='text' className='form-control' onChange={(e) => e.target.value} value={cart.qty} />
																				<button type='button' onClick={() => incrementQuantity(cart)} className='btn-icon default'>+</button>
																			</div> */}

																			<Counter count={cart.qty} decrementQuantity={decrementQuantity} incrementQuantity={incrementQuantity}  />
																		</td>
																		<td><FormatPrice price={cart.price * cart.qty} /></td>
																		<td>
																			<button type='button' className='btn-icon' onClick={() => removeCart(cart.item_id)}><img src={IconClose} title='' /></button>
																		</td>
																	</tr>
																)
															})
														}
													</tbody>
												</table>
											</div>
											<div className='d-flex justify-content-between align-items-center'>
												<div className='coupon'>
													<input type='text' style={{ textTransform: 'uppercase' }} className='form-control' onChange={(e) => setCoupon(e.target.value)} placeholder='Coupon Code' />
													<button type='button' onClick={handleCoupon} className='btn btn-primary'>Apply</button>
												</div>
												<Link to='/checkout' className='btn btn-secondary'>Proceed to Checkout</Link>
											</div>
										</div>
										<div className='col-lg-3'>
											<CartTotal />
										</div>
									</div>
								) : (
									<div className='section-sm empty-cart all-center text-center'>
										<div className='col-lg-5'>
											<img src={NoCartImage} />
											<h2>Your cart is Empty</h2>
											<p>If you have any questions or need assistance, feel free to reach out to our customer support. Happy shopping!"</p>
											<Link to='/menus' className='btn btn-primary'>Continue Shopping</Link>
										</div>
									</div>
								)
							}
						</>
					) : (
						<div className='section-sm empty-cart all-center text-center'>
							<div className='col-lg-5'>
								<img src={NoCartImage} />
								<h2>Your cart is Empty</h2>
								<p>Login to see the items you added previously</p>
								<Link to='/login' className='btn btn-primary'>Login</Link>
							</div>
						</div>
					)
				}
			</div>
		</div>
	)
}

export default Carts;