import { configureStore } from "@reduxjs/toolkit";
import { combineReducers } from "@reduxjs/toolkit";
import thunk from "redux-thunk";
import storage from "redux-persist/lib/storage";
import { persistReducer } from "redux-persist";

import authSlice from './slices/authSlice';
import menuSlice from './slices/menuSlice';
import categorySlice from './slices/categorySlice';
import cartSlice from './slices/cartSlice';

const rootReducers = combineReducers({
    authSlice,
    menuSlice,
    categorySlice,
    cartSlice
})

const persistConfig = {
    key: "root",
    storage,
};

const persistedReducer = persistReducer(persistConfig, rootReducers);

export const store = configureStore({
    reducer: persistedReducer,
    middleware: [thunk],
})
