import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Toaster from './utils/toaster';
import Interceptor from './API/interceptor/Interceptor';
import Components from './component';
import Pages from './pages';
import PrivateRoute from './component/routing/PrivateRoute';
import Demo from './pages/demo';

function App() {

  const { Header, Footer } = Components
  const { Login, MyAccount, Home, Menus, Carts, Checkout, OrderMessage, State  } = Pages;

  return (
    <>
      <State />
      {/* <Toaster />
      <Interceptor />
      <Router>
        <Header />
        <Routes>
          <Route path='/' element={<Home />} />
          <Route path='/login' element={<Login />} />
          <Route path='/my-account' element={<MyAccount />} />
          <Route path='/home' element={<Home />} />
          <Route path='/menus/:id' element={<Menus />} />
          <Route path='/carts' element={<Carts />} />
          <Route path='/checkout' element={<Checkout />} />
          <Route path='/order-place' element={<OrderMessage />} />
        </Routes>
      </Router> */}
    </>
  );
}

export default App;
