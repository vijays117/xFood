import React, { useState } from 'react';
import { useEffect } from 'react';
import apiService from '../../API/api/Api';
import ImagesData from '../../assets/ImagesData.js';

const CurrentLocation = () => {

    // Images
    const { IconLocation } = ImagesData;

    const [location, setLocation] = useState(null);

    useEffect(() => {
        if (navigator.geolocation) {
            navigator.geolocation.getCurrentPosition(async (position) => {
                const { latitude, longitude } = position.coords;
                try {
                    const response = await apiService.get(`https://nominatim.openstreetmap.org/reverse?format=json&lat=${latitude}&lon=${longitude}`);
                    if (response) {
                        const { postcode, city, state } = response.address
                        setLocation({ postcode, city: city || '-', state })
                    }
                } catch { }
            })
        }
    }, [])
    // .split(/\s+/).map(word => word[0]).join('')
    return (
        <>
            {
                location && ( 
                <p className='h-center'>
                    <span className='icon-img-inline'><img src={IconLocation} className='d-block' title='' /></span>
                    {`${location.postcode} ${location.city != 'undefined' && location.city} ${location.state}`}
                </p>
                )
            }
        </>
    )
}

export default CurrentLocation;