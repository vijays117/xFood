import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import Banner from '../../component/banner';
import ImagesData from '../../assets/ImagesData.js';
import apiService from '../../API/api/Api';

const Home = () => {

	const { ImgOutlet1, ImgOutlet2, ImgOutlet3, ImgOutlet4, ImgWork1, ImgWork2, ImgWork3, ImgWork4, ImgOffer } = ImagesData;

	const [outlets, setOutlets] = useState([]);

	const fetchOutlets = async () => {
		const response = await apiService.get('/Outlets')
		setOutlets(response.outletdata)
	}

	useEffect(() => {
		fetchOutlets();
	}, [])

	return (
		<>
			<Banner />
			<div className='section outlet-section'>
				<div className='container'>
					<div className='heading text-center'>
						<h2>{outlets?.length} Best Outlets in Your City</h2>
					</div>
					<div className='row'>
						{
							outlets?.map((outlet, i) => {
								return (
									<div className='col-lg-3' key={i}>
										<div className='column'>
											<div className='img'>
												<Link to={`/menus/${outlet.outlet_id}`}><img src={`https://saddaaddarestaurant.com/adminlogin/images/${outlet.outlet_image}`} className='d-block' title='' /></Link>
											</div>
											<div className='text'>
												<h3>{outlet.outlet_name.slice(0, 25)}</h3>
												<p>{outlet.outlet_address.slice(0, 55)}</p>
											</div>
										</div>
									</div>
								)
							})
						}
					</div>
				</div>
			</div>
			<div className='section work-section text-center pt-30'>
				<div className='container'>
					<div className='heading'>
						<h2>How It Works</h2>
					</div>
					<div className='row'>
						<div className='col-lg-3'>
							<div className='column'>
								<div className='img'>
									<img src={ImgWork1} title='' />
								</div>
								<h3>Choose Your Favorite</h3>
							</div>
						</div>
						<div className='col-lg-3'>
							<div className='column'>
								<div className='img'>
									<img src={ImgWork2} title='' />
								</div>
								<h3>HomeChef Will Cook</h3>
							</div>
						</div>
						<div className='col-lg-3'>
							<div className='column'>
								<div className='img'>
									<img src={ImgWork3} title='' />
								</div>
								<h3>We Deliver Your Meals</h3>
							</div>
						</div>
						<div className='col-lg-3'>
							<div className='column'>
								<div className='img'>
									<img src={ImgWork4} title='' />
								</div>
								<h3>Eat And Enjoy</h3>
							</div>
						</div>
					</div>
				</div>
			</div>
			<div className='section offer-section'>
				<div className='container'>
					<div className='row align-items-center'>
						<div className='col-lg-6'>
							<div className='col-img'>
								<img src={ImgOffer} title='' />
							</div>
						</div>
						<div className='col-lg-6'>
							<div className='col-text'>
								<h2>Get the menu of your favorite restaurants every day</h2>
							</div>
						</div>
					</div>
				</div>
			</div>
		</>
	)
}

export default Home;