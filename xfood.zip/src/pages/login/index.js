import React from 'react';
import { useForm } from 'react-hook-form';
import { useNavigate } from 'react-router-dom';
import { useDispatch, useSelector } from 'react-redux';
import apiService from '../../API/api/Api';
import { showToast } from '../../utils/toaster/index';
import { saveUserDetail } from '../../store/slices/authSlice';

const Login = () => {

    const navigate = useNavigate();
    const dispatch = useDispatch();
    const { handleSubmit, register, formState: { errors } } = useForm();

    const onSubmit = async(data)=>{
        try{
            const response = await apiService.post('/AuthController/login', data)
            if(response.status = '200'){
                dispatch(saveUserDetail(response.token))
                showToast(response.message, 'success');
                setTimeout(()=>{
                    navigate('/home')
                }, 500)
            }
        }
        catch{ }
    }

    return (
        <div className='section form-page'>
            <div className='container'>
                <div className='all-center'>
                    <div className='col-lg-4'>
                        <div className='heading text-center'>
                            <h2>Login</h2>
                        </div>
                        <form onSubmit={handleSubmit(onSubmit)}>
                            <div className='form-group'>
                                <input type='text'
                                    className='form-control'
                                    name='mobile'
                                    defaultValue='9871579746'
                                    {...register('mobile', { required: 'Mobile is required' })}
                                    placeholder='Mobile' />
                                {errors.mobile && <span className='error'>{errors.mobile.message}</span>}
                            </div>
                            <div className='form-group'>
                                <input type='text'
                                    className='form-control'
                                    name='otp'
                                    defaultValue='1234'
                                    {...register('otp', { required: 'OTP is required' })}
                                    placeholder='OTP' />
                                {errors.otp && <span className='error'>{errors.otp.message}</span>}
                            </div>
                            <div className='form-group'>
                                <button type='submit' className='btn btn-primary btn-block'>Login</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    )
}

export default Login;