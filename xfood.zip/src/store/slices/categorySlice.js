import { createSlice, createAsyncThunk } from "@reduxjs/toolkit";
import apiService from '../../API/api/Api'

const initialState = {
    categories: [],
}

// Fetch Profile 
export const fetchCategories = createAsyncThunk('fetchCategories', async()=>{
    try{
        const response = await apiService.get(`Category`);
        if (response.status == 200) {
            return response.categorydata
        }
    } catch (error) { }
})

const categorySlice = createSlice({
    name: 'categorySlice',
    initialState,
    extraReducers: (builder)=>{
        builder.addCase(fetchCategories.fulfilled, (state, action)=>{
            state.categories = action.payload
        })
    }
})

export default categorySlice.reducer;