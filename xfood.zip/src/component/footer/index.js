import React from 'react';

const Footer = () => {
    return (
        <div className="footer">
            <div className="container">
                <div className="footer-top">
                    <div className="row">
                        <div className="col-lg-4 col-sm-6 col-xs-12">
                            <div className="column">
                                <span><img src="./images/icon-grate-value.webp" title="" /></span>
                                <h5>Great Value</h5>
                                <p>Most popular brands with widest range of selection at best prices.</p>
                            </div>
                        </div>
                        <div className="col-lg-4 col-sm-6 col-xs-12">
                            <div className="column">
                                <span><img src="./images/icon-nation-delivery.webp" title="" /></span>
                                <h5>Seamless Delivery</h5>
                                <p>Over 20 States accessible throughout India.</p>
                            </div>
                        </div>
                        <div className="col-lg-4 col-sm-6 col-xs-12">
                            <div className="column">
                                <span><img src="./images/icon-securePayment.webp" title="" /></span>
                                <h5>Flexible Payment Agreement</h5>
                                <p>Payment Schedules can be tailored to the customer specific situation.</p>
                            </div>
                        </div>
                    </div>
                </div>
                <div className="footer-middle">
                    <div className="row">
                        <div className="col-lg-6 col-sm-12">
                            <p>info@arostore.com</p>
                        </div>
                        <div className="col-lg-6 col-sm-12 text-right">
                            <p>Mobile:- +91 9871579746</p>
                        </div>
                    </div>
                </div>
                <div className="footer-bottom text-center">
                    <p><span><a href="#">Terms of Use</a></span><span><a href="#">Privacy Policy</a></span></p>
                    <p>Copyright @2023 Aro Store Private Limited</p>
                </div>
            </div>
            <img src="images/contact_globe.svg" className="globe" title="" alt="" />
        </div>
    )
}

export default Footer;