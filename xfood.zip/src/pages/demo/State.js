import React, { useState } from 'react';

const State = () => {

    const [count, setCount] = useState(0);
    // console.log('Top', count)

    const decrement = ()=>{
        console.log('d')
    }

    const increment = () => {
        setCount(prevCount => {
          const newCount = prevCount + 1;
          if (newCount === 5) {
            console.log('Yes');
          }
          return newCount;
        });
    };

    // console.log('Bottom', count)

    return (
        <div className='section container'>
            <div className='all-center'>
                <div className='h-center'>
                    <span onClick={decrement} className='btn btn-primary'>-</span>
                    <span className='text-center col-lg-4 d-block'>{count}</span>
                    <span onClick={increment} className='btn btn-primary'>+</span>
                </div>
            </div>
        </div>
    )
}

export default State;