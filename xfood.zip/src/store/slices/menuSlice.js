import { createSlice, createAsyncThunk } from "@reduxjs/toolkit";
import apiService from '../../API/api/Api'

const initialState = {
    menus: [],
}

// Fetch Profile 
export const fetchMenus = createAsyncThunk('fetchMenus', async(id)=>{
    try{
        const response = await apiService.get(`Outletsmenu/${id}`);
        if (response.status == 200) {
            return response.outlet_menu_data
        }
    } catch (error) { }
})

const menuSlice = createSlice({
    name: 'menuSlice',
    initialState,
    extraReducers: (builder)=>{
        builder.addCase(fetchMenus.fulfilled, (state, action)=>{
            state.menus = action.payload
        })
    }
})

export default menuSlice.reducer;