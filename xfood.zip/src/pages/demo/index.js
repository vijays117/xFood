import React from 'react';

const Demo = () => {

    function updateHeaderBackgroundColor() {
        const header = document.getElementById('header');
        const targetDivs = document.querySelectorAll('.targetDiv');

        let lastVisibleIndex = -1;

        let currentVisibleIndex = -1;
        for (let i = 0; i < targetDivs.length; i++) {
            const rect = targetDivs[i].getBoundingClientRect();
            if (rect.top >= 0 && rect.top <= window.innerHeight) {
                currentVisibleIndex = i;
                break;
            }
        }

        if (currentVisibleIndex !== -1) {
            if (currentVisibleIndex !== lastVisibleIndex) {
                lastVisibleIndex = currentVisibleIndex;
                // header.style.backgroundColor = '#ddd';
                header.classList.add('yes')
            }
        } else {
            lastVisibleIndex = -1;
            // header.style.backgroundColor = 'yellow'; // Change this to your default background color
            header.classList.remove('yes')
        }
    }

    window.addEventListener('scroll', updateHeaderBackgroundColor);

    return (
        <>
            <div className='newHeader' id='header'>index</div>
            <div className='secton dummy-section'></div>
            <div className='targetDiv one'></div>
            <div className='secton dummy-section'></div>
            <div className='targetDiv two'></div>
            <div className='secton dummy-section'></div>
            <div className='targetDiv three'></div>
            <div className='secton dummy-section'></div>
        </>
    )
}

export default Demo;