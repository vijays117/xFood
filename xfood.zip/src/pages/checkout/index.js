import React, { useEffect, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { useNavigate } from 'react-router-dom';
import { deliverChargeAction, clearCartState } from '../../store/slices/cartSlice'
import Components from '../../component';
import apiService, { api } from '../../API/api/Api';

const Checkout = () => {

  const navigate = useNavigate();
  const dispatch = useDispatch();

  const [billingForm, setBillingForm] = useState({
    pincode: '',
    address: '',
    paymentMode: '',
    notes: ''
  })

  const handleChange = async(e)=>{
    const { name, value } = e.target
    setBillingForm((prevData)=>({
      ...prevData,
      [name] : value
    }))
  }

  const getDeliveryCharges = async()=>{
    if(billingForm.pincode.length == 6){
      try{
        const response = await apiService.get(`Delevery_charge/${billingForm.pincode}`)
        if(response.status == 200){
          dispatch(deliverChargeAction(response.delevery_charge_data[0].delevery_chage))
        }
        else{
          dispatch(deliverChargeAction(0))
        }
      } catch {}
    }
  }

  useEffect(()=>{
    getDeliveryCharges()
  }, [billingForm.pincode])

  const { CartTotal } = Components;
  const { userId } = useSelector((state)=> state.authSlice);
  const { carts, deliveryCharge, coupons, total } = useSelector((state)=> state.cartSlice);

  const handleSubmit = async(e)=>{
    e.preventDefault();
    const payload = {"user_id": userId, "outlet_id": carts[0].outlet_id, "discount_amount": coupons ? coupons : 0, "delivery_charge": deliveryCharge ? parseFloat(deliveryCharge) : 0, "delivery_address": billingForm.address, "payment_mode": billingForm.paymentMode, "order_note": billingForm.notes, "pay_amount": total && total, "payment_status" : 1}
    const response = await apiService.post('/New_order', payload);
    if(response.status == '200'){
      const newPayload = carts.map((item)=> ({...item, orderID: response.order_id, "payment_mode": 0, "tax": 0}))
      const newResponse = await apiService.post('/New_order/Insert_order_item', newPayload);
      if(newResponse.status == '200'){
        console.log(newResponse)
        navigate('/order-place')
        dispatch(clearCartState())
      }
    }
}

  return (
    <div className='section-sm checkout-section'>
      <div className='container'>
        <div className='heading'>
          <h3>Shapping Information</h3>
        </div>
        <div className='row'>
            <div className='col-lg-9'>
              <div className='default-box'>
              <form className='row row-sm' onSubmit={handleSubmit}>
              <div className='col-lg-4'>
                  <div className='form-group'>
                    <label>Pincode</label>
                    <input type='text' 
                      className='form-control' 
                      name='pincode'
                      value={billingForm.pincode}
                      onChange={handleChange}
                      placeholder='Pincode' />
                  </div>
                </div>
                <div className='col-lg-4'>
                  <div className='form-group'>
                    <label>Address</label>
                    <input type='text' 
                      className='form-control' 
                      name='address'
                      value={billingForm.address}
                      onChange={handleChange}
                      placeholder='Delivery Address' />
                  </div>
                </div>
                <div className='col-lg-4'>
                  <div className='form-group'>
                    <label>Select Payment Mode</label>
                    <select className='form-control' name='paymentMode' value={billingForm.paymentMode} onChange={handleChange}>
                      <option value="0">Select Payment Mode</option>
                      <option value="1">Online</option>
                      <option value="2">Cash on Delivery</option>
                      <option value="3">Take from Outlet</option>
                    </select>
                  </div>
                </div>
                <div className='col-lg-12'>
                  <div className='form-group'>
                  <label>Order Notes</label>
                    <textarea rows={5} 
                    className='form-control' 
                    name="notes"
                    value={billingForm.notes}
                    onChange={handleChange}
                    placeholder='Order Notes'></textarea>
                    {/* {errors.note && <span className='error'>{errors.note.message}</span>} */}
                  </div>
                </div>
                <div className='col-lg-12'>
                  <div className='text-right'>
                    <button type='submit' className='btn btn-primary'>Place Order</button>
                  </div>
                </div>
              </form>
              </div>
            </div>
            <div className='col-lg-3'>
              <CartTotal dCharge={billingForm.pincode} />
            </div>
          </div>
      </div>
    </div>
  )
}

export default Checkout;