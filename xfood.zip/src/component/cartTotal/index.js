import React, { useEffect, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { Link } from 'react-router-dom';
import FormatPrice from '../../utils/format-price';
import { totalCartAmount } from '../../store/slices/cartSlice';

const CartTotal = ({ dCharge }) => {

    const dispatch = useDispatch();
    const { carts, subTotal, coupons, deliveryCharge, total } = useSelector((state) => state.cartSlice);

    useEffect(()=>{
        dispatch(totalCartAmount())
    }, [carts, subTotal, coupons, deliveryCharge, total])

    return (
        <>
            <div className='cart-total'>
                <h3>Order Summary</h3>
                <p>
                    <span>Sub Total</span>
                    <span><FormatPrice price={subTotal} /></span>
                </p>
                {
                    dCharge?.length == 6 &&
                    <p>
                        <span>Shipping</span>
                        <span><FormatPrice price={deliveryCharge} /></span>
                    </p>
                }
                <p>
                    <span>Tax</span>
                    <span><FormatPrice price={subTotal * 18 / 100} /></span>
                </p>
                {
                    coupons && (
                        <p>
                            <span>Coupon</span>
                            <span><FormatPrice price={coupons} /></span>
                        </p>
                    )
                }
                <div className='total'>
                    <p>
                        <span>Total</span>
                        <span><FormatPrice price={total} /></span>
                    </p>
                </div>
            </div>
        </>
    )
}

export default CartTotal;