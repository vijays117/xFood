import Header from "./header";
import Banner from "./banner";
import Footer from "./footer";
import CartTotal from "./cartTotal";

const Components = {
    Header,
    Banner,
    Footer,
    CartTotal
}

export default Components;