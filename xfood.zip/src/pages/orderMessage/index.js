import React from 'react';

const OrderMessage = () => {
  return (
    <div className='section text-center'>
        <h1>Order Placed Successfully</h1>
    </div>
  )
}

export default OrderMessage;