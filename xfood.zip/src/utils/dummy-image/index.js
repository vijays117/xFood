import React from 'react';
import ImagesData from '../../assets/ImagesData.js';

const DummyImage = ({ imgs }) => {
    const { NoImage } = ImagesData;
    const handleImageError = (event) => {
        event.target.src = NoImage;
        event.target.classList.add('no-image')
    };
    return (
        <img src={imgs} onError={handleImageError} />
  )
}

export default DummyImage;