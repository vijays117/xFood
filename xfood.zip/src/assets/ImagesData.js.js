import Logo from './images/logo.svg';
import IconLocation from './images/icon-location.svg';
import IconBasket from './images/icon-basket.svg';
import IconHeart from './images/icon-heart.svg';
import IconUser from './images/icon-user.svg';
import IconLogout from './images/icon-logout.svg';
import IconList from './images/icon-list.svg';
import IconGrid from './images/icon-grid.svg';
import IconClose from './images/icon-close.svg';
import ImgOutlet1 from './images/img-outlet1.jpg';
import ImgOutlet2 from './images/img-outlet2.jpg';
import ImgOutlet3 from './images/img-outlet3.jpg';
import ImgOutlet4 from './images/img-outlet4.jpg';
import ImgWork1 from './images/img-work1.jpg';
import ImgWork2 from './images/img-work2.jpg';
import ImgWork3 from './images/img-work3.jpg';
import ImgWork4 from './images/img-work4.jpg';
import ImgOffer from './images/img-offer.png';
import NoImage from './images/img_no-image.png';
import NoCartImage from './images/img-no-cart.webp';

const ImagesData = {
    Logo,
    IconBasket,
    IconLocation,
    IconHeart,
    IconUser,
    IconLogout,
    IconList,
    IconGrid,
    IconClose,
    ImgOutlet1,
    ImgOutlet2,
    ImgOutlet3,
    ImgOutlet4,
    ImgWork1,
    ImgWork2,
    ImgWork3,
    ImgWork4,
    ImgOffer,
    NoImage,
    NoCartImage
}

export default ImagesData;