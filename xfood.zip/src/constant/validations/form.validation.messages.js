const Messages = {
    pass_required: "Please enter valid password",
    min_pass_length: "Password must contain minimum 6 characters",
    max_pass_length: "Password  should not be greater than 10 characters",
    strong_pass:
        "Must contain at least one character in capital one in lowercase and one numeric.",
    email_required: "Email is required",
    valid_email: "Must be a valid email",
    name_require: "Please enter full name",
    valid_name: "No special character, numbers or emojis allowed in name",
    phone_invalid: "This phone number is invalid!",
    valid_number: "Only numbers are allowed",
    min_phone_length: "Phone number should have atleast 7 characters or more",
    max_phone_length: "Phone number should not be greater than 12 Characters",
    dob_required: "Please enter date of birth",
    valid_dob: "Date of birth cant be future date",
    check_required: "Accept Terms and Conditions",
    max_firstname_length: "First name should not be greater than 200 Characters",
    max_lastname_length: "Last name should not be greater than 200 Characters",
    min_name_length:
        "Please enter valid full Name. full name should have atleast 3 characters or more",
    max_name_length: "Full name should not be greater than 100 nharacters",
    otp_invalid: "Too short. The verification code is 6-digits.",
    sign_up_alert: "Sign Up message alert",
};

export default Messages;
