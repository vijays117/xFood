import React from 'react';
import { Route, Navigate } from 'react-router-dom';
import { useSelector } from 'react-redux';

const PrivateRoute = ({ path, ...props }) => {
  const isAuthenticated = useSelector((state)=> state.authSlice.access_token);
  console.log(isAuthenticated)

  if (!isAuthenticated) {
    return <Navigate to="/login" />;
  }

  return <Route path={path} {...props} />;
};

export default PrivateRoute;