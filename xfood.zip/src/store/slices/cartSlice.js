import { createSlice, createAsyncThunk } from "@reduxjs/toolkit";
import apiService from '../../API/api/Api'

const initialState = {
    carts: [],
    subTotal: null,
    coupons: null,
    deliveryCharge: null,
    total: null
}

const cartSlice = createSlice({
    name: 'menuSlice',
    initialState,
    reducers: {
        clearCartState: () => initialState,
        addToCart: (state, {payload}) => {
            const newItem = { "item_id": payload.id, "outlet_id": payload.outletID, "price": payload.price, "product_name": payload.item_name, "qty": 1 }
            const exItem = state.carts.find((cart) => cart.product_name == newItem.product_name)
            if (exItem) {
                exItem.qty++;
              } else {
                state.carts = [...state.carts, newItem];
                // state.carts.push({...newItem });
                // state.carts.push(action.payload)
              }  
        },
        removeItemFromCart: (state, {payload}) => {
            const itemId = payload;
            state.carts = state.carts.filter(item => item.item_id !== itemId);
        },
        decrement : (state, {payload})=>{
            const newQty = state.carts.find((item)=> item.product_name == payload?.product_name)
            newQty.qty--
        },
        increment : (state, {payload})=>{
            const newQty = state.carts.find((item)=> item.product_name == payload?.product_name)
            newQty.qty++
        },
        deliverChargeAction : (state, {payload})=>{
            state.deliveryCharge = payload
        },
        getSubTotal: (state) => {
            const subTotal = state.carts.reduce((accumulator, item)=> accumulator + item.price * item.qty, 0)
            state.subTotal = subTotal
        },
        couponDiscount : (state, {payload})=>{
            state.coupons = payload?.amount
        },
        totalCartAmount : (state)=>{     
            state.total = (state.subTotal + (state.subTotal * 18 / 100) - state.coupons + state.deliveryCharge)
        }
    }
})

export const { addToCart, removeItemFromCart, increment, decrement, getSubTotal, deliverChargeAction, couponDiscount, clearCartState, totalCartAmount } = cartSlice.actions;

export default cartSlice.reducer;