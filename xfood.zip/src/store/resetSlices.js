import authSlice from "./slices/authSlice";
import cartSlice from "./slices/cartSlice";

export const resetAllSlices = (dispatch) => {
    dispatch(resetAuthState());
    dispatch(resetUserState());
    // Dispatch other reset actions if needed
};