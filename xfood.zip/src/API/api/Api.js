import axios from 'axios';

const baseURL = 'https://api.saddaaddarestaurant.com/';

export const api = axios.create({
    baseURL,
});

const apiService = {
  get: async (url, params) => {
    try {
      const response = await api.get(url, { params });
      return response.data;
    } catch (error) {
      throw new Error(error.response?.data?.message || 'An error occurred.');
    }
  },

  post: async (url, data) => {
    try {
      const response = await api.post(url, data);
      return response.data;
    } catch (error) {
      throw new Error(error.response?.data?.message || 'An error occurred.');
    }
  },

  put: async (url, data) => {
    try {
      const response = await api.put(url, data);
      return response.data;
    } catch (error) {
      throw new Error(error.response?.data?.message || 'An error occurred.');
    }
  },

  patch: async (url, data) => {
    try {
      const response = await api.patch(url, data);
      return response.data;
    } catch (error) {
      throw new Error(error.response?.data?.message || 'An error occurred.');
    }
  },

  delete: async (url, data) => {
    try {
      const response = await api.patch(url, data);
      return response.data;
    } catch (error) {
      throw new Error(error.response?.data?.message || 'An error occurred.');
    }
  },
};

export default apiService;