import React from 'react';

const Banner = () => {
    return (
        <div className='banner-section all-center'>
            <div className='container'>
                <div className='row'>
                    <div className='col-lg-7'>
                        <h1>Delivery or Takeaway Food</h1>
                        <h5>The best restaurants at the best price</h5>
                        <div className='searchbar'>
                            <input type='text' className='form-control' placeholder='Enter Your Food Name...' />
                            <button type='submit' className='btn btn-primary'><i className="fa fa-search" aria-hidden="true"></i></button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    )
}

export default Banner;