import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { useDispatch, useSelector } from 'react-redux';
import { fetchProfile, clearUserState } from '../../store/slices/authSlice';
import ImagesData from '../../assets/ImagesData.js';
import CurrentLocation from '../../utils/current-location';

const Header = () => {

  const { Logo, IconBasket, IconLocation, IconUser } = ImagesData;
  const [scrolled, setScrolled] = useState(false);

  const dispatch = useDispatch();
  const { access_token, profileData } = useSelector((state)=> state.authSlice);
  const { carts } = useSelector((state)=> state.cartSlice);

  useEffect(()=>{
    dispatch(fetchProfile(access_token))
  }, [access_token])

  const logout = ()=>{
    dispatch(clearUserState());
  }

  const handleScroll = () => {
    if (window.scrollY > 0) {
      setScrolled(true);
    } else {
      setScrolled(false);
    }
  };

  useEffect(()=>{
    window.addEventListener('scroll', handleScroll);
  })

  return (
    <div className={`header ${scrolled ? 'fixed' : ''}`}>
      <div className='container'>
        <div className='row justify-content-between align-items-center'>
          <div className='left d-flex align-items-center'>
            <div className='logo'>
              <Link to='/'><img src={Logo} className='d-block' title='' /></Link>
            </div>
            <div className='location'>
              <CurrentLocation />
            </div>
          </div>
          <div className='nav'>
            <ul>
              <li><a href='#'>Home</a></li>
              <li><Link to='/menus'>About</Link></li>
              <li><a href='#'>Blog</a></li>
              <li><a href='#'>Contact</a></li>
            </ul>
          </div>
          <div className='site-controls'>
            <ul className='d-flex align-items-center'>
              {!access_token && <li><Link to='/login'><span className='icon-img-inline'><img src={IconUser} className='d-block' title='' /></span>Login</Link></li>}
              {access_token && <li><Link to='/my-account'><span className='name'>{profileData?.name.split(/\s+/).map(word => word[0]).join('')}</span>{profileData?.name}</Link></li>}
              {access_token && <li onClick={logout}>Logout</li>}
              <li>
                <Link to='/carts'>
                  <img src={IconBasket} title='' />
                  <span className='notify'>{access_token ? carts?.length : '0'}</span>
                </Link>
              </li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  )
}

export default Header;