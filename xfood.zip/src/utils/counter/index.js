import React from 'react';

const Counter = ({count, decrementQuantity, incrementQuantity}) => {
  return (
    <div className='counter'>
        <button type='button' onClick={decrementQuantity} className='btn-icon default'>-</button>
        <input type='text' className='form-control' value={count} onChange={(e)=> e.target.value} />
        <button type='button' onClick={incrementQuantity} className='btn-icon default'>+</button>
    </div>
  )
}

export default Counter;