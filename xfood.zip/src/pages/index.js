import Login from "./login";
import MyAccount from "./myacoount";
import Home from "./home";
import Menus from "./menus";
import Carts from './carts';
import Checkout from './checkout';
import OrderMessage from './orderMessage';
import State from "./demo/State";

const Pages = {
    Login,
    MyAccount,
    Home,
    Menus,
    Carts,
    Checkout,
    OrderMessage,
    State
}

export default Pages;