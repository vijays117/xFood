import React, { useEffect, useState } from 'react';
import { useSelector } from 'react-redux';
import { Link } from 'react-router-dom';
import apiService from '../../API/api/Api';
import axios from 'axios';

const MyAccount = () => {

    const { userId } = useSelector((state)=> state.authSlice)
    const [orders, setOrders] = useState([])

    const fetchMyOrders = async() => {
        const response = await apiService.get(`/Order_history/customer_order_history/${userId}`)
        if(response.status == '200'){
            setOrders(response.customer_order_data)
        }
    }

    useEffect(()=>{
        fetchMyOrders();
    }, [])

    return (
        <div className='section account-page'>
            <div className='container'>
                <div className='row'>
                    <div className='col-lg-3'>
                        <div className='sidebar'>
                            <ul>
                                <li><Link>Profile</Link></li>
                                <li><Link>Order</Link></li>
                                <li><Link>Profile</Link></li>
                            </ul>
                        </div>
                    </div>
                    <div className='col-lg-9'>
                        <div className='panel'>
                            <div className='header'>
                                <h3>My Orders</h3>
                            </div>
                            <div className='orders'>
                                {
                                    orders.map((order, i)=>{
                                        return(
                                            <div className='order' key={i}>
                                                <div className='img'>
                                                    <img src={`https://saddaaddarestaurant.com/adminlogin/images/${order.outlet_image}`} />
                                                </div>
                                            </div>
                                        )
                                    })
                                }
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    )
}

export default MyAccount