import React, { useEffect, useState } from 'react';
import { api } from '../api/Api';

const Interceptor = () => {

    const apis = api;
    const [loading, setLoading] = useState(false);

    useEffect(() => {
        // Request interceptor
        const requestInterceptor = apis.interceptors.request.use((config) => {
            setLoading(true);
            return config;
        }, (error) => {
            setLoading(false);
            return Promise.reject(error);
        });

        // // Response interceptor
        const responseInterceptor = apis.interceptors.response.use((response) => {
            setLoading(false);
            return response;
        }, (error) => {
            setLoading(false);
            return Promise.reject(error);
        });

        // // Cleanup interceptors
        return () => {
            apis.interceptors.request.eject(requestInterceptor);
            apis.interceptors.response.eject(responseInterceptor);
        };
    }, [])

    return (
        <>
            {( loading && 
                <section className="loader">
                    <span></span>
                    <span></span>
                    <span></span>
                    <span></span>
                </section>
            )}
        </>
    );

}

export default Interceptor;