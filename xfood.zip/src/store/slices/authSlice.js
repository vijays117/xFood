import { createSlice, createAsyncThunk } from "@reduxjs/toolkit";
import apiService from '../../API/api/Api'

const initialState = {
    access_token: null,
    profileData: [],
    userId: ''
}

// Fetch Profile 
export const fetchProfile = createAsyncThunk('fetchProfile', async(token)=>{
    try{
        const response = await apiService.get(`Customer_profile/${token}`);
        if (response.status == 200) {
            return response.user_data[0]
        }
    } catch (error) { }
})

const authSlice = createSlice({
    name: 'AuthSlice',
    initialState,
    reducers:{
        clearUserState: () => initialState,
        saveUserDetail : (state, action)=>{
            state.access_token = action.payload
        }
    },
    extraReducers: (builder)=>{
        builder.addCase(fetchProfile.fulfilled, (state, action)=>{
            state.profileData = action.payload
            state.userId = action.payload?.user_id
        })
    }
})

export const { saveUserDetail, clearUserState } = authSlice.actions

export default authSlice.reducer;