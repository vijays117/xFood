import React from 'react';
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';

const Toaster = () => {
    return <ToastContainer />;
}

export const showToast = (message, type) => {
    toast(message, {
      type: type,
      autoClose: 2000,
      position: "top-center",
      theme: "colored",
    });
};

export default Toaster;